import React from "react";
import style from "./Dropdown.module.css";

const Dropdown = () => (
  <div className={style.container}>
    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ullam, laboriosam.
    <button type="button">Logout =></button>
  </div>
);

export default Dropdown;
